# Autonomous Outbound SDR Swarm and Lead Generation Engine

> Architectural Blueprint: Nick Saraev (Founder, LeftClick.ai and Maker School)  
> System Classification: Enterprise Multi Agent System (B2B Outbound SDR Operations)  
> Core Design Pattern: The DOE Framework (Directive, Orchestration, Execution) with LangGraph Supervisor  
> Target Output Directory: `/home/idrees/Antigravity/agentic_workflows_vault/blueprints/workflow_1_nick_saraev/`

---

## 1. Executive Summary and Architecture Overview

Traditional B2B outbound prospecting suffers from severe operational inefficiencies. Human SDR teams consume heavy payroll budgets while dedicating eighty percent of their working hours to repetitive data entry, shallow list scraping, and generic email generation. Brittle linear automations break whenever website layouts shift, API endpoints throttle, or anomalous data structures appear. Furthermore, generic cold blast campaigns trigger high spam reports and burn company sending domains.

This production grade blueprint translates Nick Saraev's flagship multi agent SDR swarm into an executable Python and LangGraph system. Rather than relying on fragile linear chains, the system implements an autonomous supervisor graph that manages specialized worker nodes across three decoupled layers:

* **Directive Layer:** Governs rules of engagement, ideal customer profile definitions, the Nick Saraev low ego copywriting protocols, and strict formatting invariants.
* **Orchestration Layer:** A cognitive LangGraph supervisor that continuously evaluates shared workflow state, orchestrates dynamic worker routing, manages self annealing error recovery, and enforces a confidence quality gate.
* **Execution Layer:** Specialized worker nodes responsible for nominative waterfall email resolution, Firecrawl website account scraping, low ego copywriting synthesis, evaluation scoring, human review staging, and campaign injection.

The architecture generates fifteen to twenty qualified inbound sales appointments weekly at an operational infrastructure cost of pennies per run.

---

## 2. Directed Acyclic Graph (DAG) and System Workflow

The diagram below illustrates the state machine topology, supervisor routing loops, and evaluation branches:

```mermaid
flowchart TD
    START([Workflow Start]) --> SUP[Supervisor Router]

    subgraph WORKERS [Specialized Execution Agents]
        ENRICH[Nominative Waterfall Enrichment]
        CRAWL[Firecrawl Deep Account Research]
        COPY[Low Ego Copywriter Engine]
    end

    subgraph GATES [Quality Evaluation and Safety Rails]
        EVAL[Quality Evaluator Node]
        GATE{Confidence Score >= 0.85?}
        HUMAN[Human In The Loop Exception Queue]
    end

    subgraph DISPATCH [Campaign Delivery Infrastructure]
        DISP[Instantly or Smartlead Dispatcher]
        DONE([Workflow Complete])
    end

    SUP -->|Needs Verified Email| ENRICH
    ENRICH -->|Email Resolved| SUP

    SUP -->|Needs Account Signals| CRAWL
    CRAWL -->|Bottlenecks Extracted| SUP

    SUP -->|Needs Outbound Copy| COPY
    COPY -->|Draft Generated| SUP

    SUP -->|Evaluate Quality| EVAL
    EVAL --> GATE

    GATE -->|Approved Score >= 0.85| SUP
    GATE -->|Flagged Score < 0.85| HUMAN
    HUMAN --> DONE

    SUP -->|Ready For Dispatch| DISP
    DISP -->|Lead Staged| SUP
    SUP -->|Workflow Finished| DONE
```

### State Machine Transition Lifecycle

1. **Initialization (`INITIAL`):** Lead enters system with company name, website domain, and decision maker identity.
2. **Waterfall Enrichment (`NEEDS_ENRICHMENT`):** Queries Anymailfinder or nominative heuristics to guarantee deliverable mailboxes. Transitions state to `ENRICHED`.
3. **Deep Web Crawl (`NEEDS_RESEARCH`):** Invokes Firecrawl to scrape website markdown, identifying core services, technology stacks, and operational bottlenecks. Transitions state to `RESEARCHED`.
4. **Copy Synthesis (`NEEDS_DRAFT`):** Applies the Nick Saraev 4 Pillar protocol to craft an understated, conversational email. Transitions state to `DRAFTED`.
5. **Quality Evaluation (`EVALUATING`):** Validates copy against factual relevance, tone authenticity, deliverability score, and zero dash compliance.
6. **Automated Approval or Human Staging:** Scores meeting or exceeding 0.85 transition to `APPROVED`. Scores below 0.85 divert to `PENDING_HUMAN_REVIEW`.
7. **Campaign Injection (`APPROVED`):** Stages verified contact and personalized copy into Instantly or Smartlead via REST API. Transitions state to `DISPATCHED` and terminates cleanly at `COMPLETE`.

---

## 3. Specialized Node Architecture

### A. Supervisor Router (`supervisor_node`)
The cognitive orchestrator of the entire system. Instead of hardcoded sequential chains, the supervisor node evaluates current state attributes, error logs, and execution counters:
* Evaluates whether prerequisites for downstream nodes are satisfied.
* Prevents infinite loops by terminating failed runs that exceed three retries.
* Routes traffic conditionally via `supervisor_route_edge` to the appropriate worker.

### B. Nominative Waterfall Enrichment (`enrichment_node`)
Guarantees clean inbox placement and protects sender domain reputation:
* Validates DNS MX records on target domains.
* Calls Anymailfinder REST API when credentials exist.
* Employs intelligent nominative pattern fallbacks when external providers are offline.
* Emits deliverability confidence scores from 0.0 to 1.0.

### C. Firecrawl Account Intelligence (`firecrawl_node`)
Conducts automated deep research on prospect web properties:
* Crawls homepage, about pages, and case studies to return clean markdown.
* Pinpoints operational bottlenecks such as manual intake, high lead volume triage, or staffing constraints.
* Extracts verifiable business achievements to ground outbound copy in reality.

### D. Low Ego Copywriting Synthesizer (`copywriter_node`)
Generates high converting cold outreach grounded in Nick Saraev's psychological principles:
* Formulates casual, lowercase subject lines of two to four words.
* Injects genuine operational context extracted during the crawl.
* Enforces strict formatting invariants, completely eliminating hyphens, em dashes, or en dashes in prose.

### E. Quality Evaluator and Confidence Gate (`evaluator_node`)
Acts as an autonomous editor and safety net before any email touches prospects:
* Evaluates four core dimensions: factual relevance (0.25), conversational tone markers (0.35), email deliverability (0.20), and zero dash compliance (0.20).
* Generates a composite confidence score between 0.0 and 1.0.
* Flags any copy with dash violations or unverified mailboxes for immediate review.

### F. Human In The Loop Exception Handler (`human_review_node`)
Provides safety governance for edge cases:
* Captures drafts falling below the 0.85 confidence threshold.
* Formats comprehensive review notes detailing specific scoring deductions.
* Allows operators to inspect, adjust, and approve edge cases without restarting the entire graph.

### G. Campaign Dispatcher (`dispatcher_node`)
Connects the cognitive swarm to physical email delivery infrastructure:
* Prepares custom payload variables containing recipient name, company, subject, and body.
* Integrates directly with Instantly or Smartlead endpoints.
* Logs delivery timestamps and campaign identifiers for tracking.

---

## 4. The Nick Saraev 4 Pillar Outbound Protocol

Outbound conversion relies on low ego, conversational Western founder framing rather than corporate hyperbole. The copywriter node strictly enforces four foundational psychological pillars:

* **Pillar 1: Immediate Proof of Competence:** Demonstrates a concrete mechanism or automated workflow solving a specific operational bottleneck.
* **Pillar 2: High Status Abundance Framing:** Communicates genuine commercial momentum without desperation: "Frankly I am drowning in opportunities right now and was wondering if you were open to taking some of these on."
* **Pillar 3: Irresistible Zero Risk Offer:** Eliminates financial and operational friction: "Wouldn't cost you anything, I will do all the configuration upfront."
* **Pillar 4: Soft Non Pushy Close:** Defuses sales pressure: "If this is not the right fit no hard feelings at all, just wanted to put that out there. Let me know."

---

## 5. Execution and Setup Guide

### Prerequisites
* Python 3.10 or higher (Python 3.13 recommended)
* Virtual environment with LangGraph and Pydantic installed

### Environment Configuration

Set optional external API keys in your environment or local `.env` file:

```bash
# Web crawling and account intelligence
export FIRECRAWL_API_KEY="fc_your_firecrawl_api_key"

# Deliverability and email resolution
export ANYMAILFINDER_API_KEY="amf_your_anymailfinder_api_key"

# LLM reasoning and advanced synthesis
export ANTHROPIC_API_KEY="sk_ant_your_anthropic_key"

# Outbound delivery infrastructure
export INSTANTLY_API_KEY="inst_your_instantly_key"
export DEFAULT_CAMPAIGN_ID="camp_saraev_sdr_01"
```

If API keys are omitted, all nodes execute gracefully with built in heuristics and simulation engines, ensuring zero crash execution out of the box.

### Quick Start Standalone Execution

Run the built in validation pipeline to execute a sample prospect through the complete graph:

```bash
cd /home/idrees/Antigravity/agentic_workflows_vault/blueprints/workflow_1_nick_saraev
python3 nodes.py
```

### Programmatic Integration Example

```python
from state import ProspectWorkflowState
from nodes import build_graph
from langchain_core.messages import HumanMessage

# Initialize compiled LangGraph workflow
app = build_graph()

# Define prospect input payload
prospect_data: ProspectWorkflowState = {
    "company_name": "Rock Road Dental",
    "website_url": "https://rockroaddental.ie",
    "decision_maker_name": "Dr Marcus Thorne",
    "decision_maker_title": "Clinical Director",
    "target_niche": "Private Dental Clinics",
    "verified_email": None,
    "deliverability_score": 0.0,
    "enrichment_source": "",
    "is_deliverable": False,
    "core_offering": "",
    "detected_bottleneck": "",
    "key_achievements": [],
    "tech_stack_signals": [],
    "crawled_summary": "",
    "drafted_subject": "",
    "drafted_body": "",
    "hook_angle": "",
    "confidence_score": 0.0,
    "dash_check_passed": False,
    "evaluation_rationale": "",
    "hitl_approved": False,
    "review_notes": "",
    "dispatch_status": "",
    "campaign_id": "",
    "status": "INITIAL",
    "retry_count": 0,
    "error_log": [],
    "messages": [HumanMessage(content="Start SDR prospecting run")]
}

# Execute state machine
final_state = app.invoke(prospect_data)

# Access validated results
print("Status:", final_state["status"])
print("Verified Email:", final_state["verified_email"])
print("Subject:", final_state["drafted_subject"])
print("Body:\n", final_state["drafted_body"])
print("Confidence Score:", final_state["confidence_score"])
```

---

## 6. Enterprise Best Practices and Deliverability Safeguards

* **Strict Domain Protection:** Never bypass the enrichment node. Sending to unverified or catch all addresses damages primary domain reputation.
* **Respect Sending Throttles:** Cap sending velocity at thirty to fifty emails per inbox daily across warmed secondary domains.
* **Separation of Concerns:** Maintain prompt directives and ICP criteria in structured configuration files, allowing non technical operators to tune campaign copy without modifying core graph code.
* **Continuous Feedback:** Utilize the human in the loop exception queue to gather rejected copy samples, feeding those patterns back into the quality evaluator rubric.
