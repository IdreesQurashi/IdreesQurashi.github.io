"""
State and Pydantic Schemas for Nick Saraev Enterprise Outbound SDR Swarm.
Implements the DOE (Directive, Orchestration, Execution) framework state.
"""

from typing import Annotated, Any, Dict, List, Literal, Optional, Sequence, TypedDict
import operator
from pydantic import BaseModel, Field
from langchain_core.messages import BaseMessage


# ---------------------------------------------------------------------------
# Pydantic Schemas for Structured I/O and Worker Payloads
# ---------------------------------------------------------------------------

class ProspectInput(BaseModel):
    """Initial input data provided for a prospective account."""
    company_name: str = Field(..., description="Target company legal or trading name")
    website_url: str = Field(..., description="Target company primary website URL")
    decision_maker_name: str = Field(..., description="Full name of target prospect")
    decision_maker_title: str = Field(..., description="Job title of target prospect")
    target_niche: Optional[str] = Field(default="B2B Technology", description="Target industry vertical")


class EnrichmentResult(BaseModel):
    """Waterfall email resolution output."""
    verified_email: Optional[str] = Field(None, description="Deliverable SMTP verified email address")
    deliverability_score: float = Field(default=0.0, description="Confidence score from 0.0 to 1.0")
    enrichment_source: str = Field(default="synthetic", description="Provider used for email resolution")
    is_deliverable: bool = Field(default=False, description="Whether email passed MX and SMTP checks")


class AccountIntelligence(BaseModel):
    """Deep research and web crawl signals gathered by Firecrawl."""
    core_offering: str = Field(..., description="Primary service or product sold by target company")
    detected_bottleneck: str = Field(..., description="Operational, hiring, or workflow bottleneck detected")
    key_achievements: List[str] = Field(default_factory=list, description="Recent wins, clients, or milestones")
    tech_stack_signals: List[str] = Field(default_factory=list, description="Observed tools and technologies")
    crawled_summary: str = Field(default="", description="Clean markdown summary of key website pages")


class CopywritingResult(BaseModel):
    """Outbound email copy synthesized using the Nick Saraev Protocol."""
    subject_line: str = Field(..., description="Casual, lowercase subject line with 2 to 4 words")
    email_body: str = Field(..., description="Low ego, high abundance personalized body copy")
    hook_angle: str = Field(..., description="The commercial trigger or operational bottleneck addressed")
    compliance_zero_dashes: bool = Field(default=True, description="Strict zero dash formatting verification")


class QualityEvaluationResult(BaseModel):
    """Evaluation gate output scoring email quality and compliance."""
    confidence_score: float = Field(..., description="Aggregate quality score between 0.0 and 1.0")
    relevance_score: float = Field(..., description="Relevance to verified account intelligence")
    tone_score: float = Field(..., description="Adherence to casual low ego Western founder tone")
    dash_check_passed: bool = Field(..., description="True if no hyphens or dashes exist in generated copy")
    rationale: str = Field(..., description="Evaluator justification and feedback notes")
    requires_human_review: bool = Field(..., description="Triggered when confidence score is under 0.85")


class DispatchResult(BaseModel):
    """Campaign staging and sending record."""
    campaign_id: str = Field(default="", description="Instantly or Smartlead campaign identifier")
    lead_id: str = Field(default="", description="Platform lead record identifier")
    status: str = Field(default="STAGED", description="Dispatch status: STAGED, SCHEDULED, or SENT")
    timestamp: str = Field(default="", description="ISO timestamp of staging action")


# ---------------------------------------------------------------------------
# LangGraph Workflow State (TypedDict)
# ---------------------------------------------------------------------------

class ProspectWorkflowState(TypedDict):
    """
    Central shared state tracking a prospect through the autonomous SDR swarm.
    """
    # Lead Identification
    company_name: str
    website_url: str
    decision_maker_name: str
    decision_maker_title: str
    target_niche: str

    # Enrichment Layer
    verified_email: Optional[str]
    deliverability_score: float
    enrichment_source: str
    is_deliverable: bool

    # Research & Intelligence Layer (Firecrawl)
    core_offering: str
    detected_bottleneck: str
    key_achievements: List[str]
    tech_stack_signals: List[str]
    crawled_summary: str

    # Copywriting Synthesis Layer (Nick Saraev Engine)
    drafted_subject: str
    drafted_body: str
    hook_angle: str

    # Confidence Evaluation & Quality Gate
    confidence_score: float
    dash_check_passed: bool
    evaluation_rationale: str
    hitl_approved: bool
    review_notes: str

    # Dispatch & Campaign Execution
    dispatch_status: str
    campaign_id: str

    # System Governance & Recovery
    status: Literal[
        "INITIAL",
        "NEEDS_ENRICHMENT",
        "ENRICHED",
        "NEEDS_RESEARCH",
        "RESEARCHED",
        "NEEDS_DRAFT",
        "DRAFTED",
        "EVALUATING",
        "APPROVED",
        "PENDING_HUMAN_REVIEW",
        "READY_FOR_DISPATCH",
        "DISPATCHED",
        "FAILED",
        "COMPLETE"
    ]
    retry_count: int
    error_log: List[str]
    messages: Annotated[Sequence[BaseMessage], operator.add]
