# Production Multi Agent Autonomous Software Engineer and Code Architect

## 1. Architectural Provenance and Reference Attribution

* **Primary Creator Attribution:** IndyDevDan (Daniel Avila, Agentic Engineer) and Dave Ebbelaar (Datalumina AI Architect)
* **Flagship Video Reference:** Claude Code Multi Agent Orchestration with Opus, Tmux and Agent Sandboxes (IndyDevDan)
* **Companion Architecture:** Building Autonomous AI Software Engineers in LangGraph (Dave Ebbelaar)
* **Architectural Classification:** Production Hierarchical Multi Agent Software Development System (Devin, SWE agent, and OpenHands Paradigm)

## 2. Core Problem Solved: Beyond Monolithic Coding Assistants

Single prompt coding models degrade rapidly when faced with complex production codebases due to four fundamental bottlenecks:

- Context Window Contamination: Ingesting entire repositories into one prompt exhausts tokens, introduces hallucinated imports, and degrades reasoning quality.
- Uncontained Host Execution Risk: Running unverified agent edits directly on developer machines risks deleted files, corrupted environments, and unvetted command execution.
- Absence of Empirical Verification: Single prompt models guess what working code looks like syntactically, but they cannot execute test suites, analyze runtime exit codes, or observe exceptions without human intervention.
- Infinite Hallucination Loops: When an implementation error occurs, flat agents repeatedly rewrite the same lines of code without systematic root cause isolation, burning API credits while compounding technical debt.

This blueprint eliminates these vulnerabilities by implementing a specialized multi agent hierarchy organized around a strict Test Driven Development Red Green Audit cycle within ephemeral sandboxes.

## 3. Multi Agent Hierarchy and Role Specifications

### Lead Architect and Planner Agent (The Coordinator)
- Primary Mission: High level codebase reconnaissance, Abstract Syntax Tree inspection, interface analysis, and task graph generation.
- Context Boundary: Ingests only directory structures, interface definitions, and issue descriptions. Strictly prohibited from generating implementation code to preserve context capacity.
- Primary Deliverable: Structured Directed Acyclic Graph specifying target files, acceptance criteria, and reproduction test requirements.

### Coder and Implementer Agent (The Specialized Builder)
- Primary Mission: Surgical synthesis of reproduction tests and targeted source code patches conforming strictly to architectural specifications.
- Context Boundary: Operates inside a fresh, isolated context window containing only the target source file, type interfaces, and failure stack traces.
- Primary Deliverable: Reproduction test suite during the Red phase, and surgical algorithmic patches during the Green phase.

### Ephemeral Sandbox Test Runner (The Empirical Executor)
- Primary Mission: Safe, unprivileged execution of tests, compilers, and linters inside isolated temporary environments.
- Context Boundary: Runs within an ephemeral workspace directory or container completely decoupled from the host operating system.
- Primary Deliverable: Structured execution receipts containing runtime duration, exit codes, failing assertions, and noise stripped stack traces.

### Critic and Security Auditor Agent (The Gatekeeper)
- Primary Mission: Adversarial code review, static AST security inspection, and regression analysis.
- Context Boundary: Inspects the unified code diff and AST parse trees with senior staff engineer skepticism.
- Primary Deliverable: AST security signoff certifying zero dangerous calls, absence of hardcoded tokens, clean exception handling, and strict file scope adherence.

### Git and Release Tooling Agent (The Deployer)
- Primary Mission: Version control automation, branch isolation, and production Pull Request publishing.
- Context Boundary: Ingests verified patch diffs, issue metadata, and empirical test execution receipts.
- Primary Deliverable: Dedicated feature branch, conventional commit formatting, and an enterprise Pull Request document featuring before and after verification evidence.

## 4. The Test Driven Development Red Green Audit Cycle

```text
+-------------------------------------------------------------+
|               1. Lead Architect & Planner                   |
|   Decomposes issue into DAG, target files & invariants      |
+------------------------------+------------------------------+
                               |
                               v
+-------------------------------------------------------------+
|              2. Coder Synthesizes Reproduction              |
|          Generates targeted test asserting bug state        |
+------------------------------+------------------------------+
                               |
                               v
+-------------------------------------------------------------+
|           3. Ephemeral Sandbox (TDD Red Phase)              |
|        Executes test against unpatched code: FAILS          |
|           Confirms bug presence and reproduction            |
+------------------------------+------------------------------+
                               |
                               v
+-------------------------------------------------------------+
|               4. Coder Implements Surgical Fix              |
|       Applies minimal algorithmic correction to target      |
+------------------------------+------------------------------+
                               |
                               v
+-------------------------------------------------------------+
|          5. Ephemeral Sandbox (TDD Green Phase)             |
|         Executes test against patched code: PASSES          |
+------------------------------+------------------------------+
                               |
                               v
+-------------------------------------------------------------+
|            6. Critic & AST Security Auditor                 |
|       Scans AST for dangerous calls, tokens, style          |
+------------------------------+------------------------------+
                               |
                               v
+-------------------------------------------------------------+
|             7. Git Tooling & Pull Request Release           |
|      Creates feature branch, commit & verified PR report    |
+-------------------------------------------------------------+
```

### Phase 1: Ingestion and Task Decomposition
The Lead Architect reads the issue description and codebase signatures. It produces an execution plan detailing root cause hypotheses, file touch boundaries, and concrete acceptance criteria.

### Phase 2: Test First Setup (TDD Red Confirmation)
The Coder constructs a dedicated reproduction test suite asserting the required behavioral invariants. The Ephemeral Sandbox executes this test against the unmodified codebase. The test must fail with a nonzero exit code. This empirical failure confirms the bug is genuine and guards against false positive verifications.

### Phase 3: Surgical Code Implementation (TDD Green Phase)
With the bug reproduced, the Coder writes a minimal, targeted patch addressing the root cause while preserving public interfaces.

### Phase 4: Autonomous Execution and Self Correction Feedback Loop
The Ephemeral Sandbox executes the reproduction suite against the patched code:
- If all assertions pass with exit code 0, the workflow advances immediately to the Critic Auditor.
- If assertions fail, the system extracts a noise stripped stack trace and failing assertion message. The Coder analyzes the failure receipt, refines the hypothesis, and updates the patch.
- A hard safety ceiling of 5 iterations prevents infinite token consumption.

### Phase 5: Adversarial Critic and AST Security Gate
The Critic Auditor evaluates the final diff using static AST analysis:
- Verifies that forbidden functions such as eval, exec, compile, and bare os.system are absent.
- Scans string literals for hardcoded API credentials, private keys, and authorization tokens.
- Ensures all modified files fall strictly within the Architect's approved target boundaries.
- Inspects exception handling to eliminate unhandled bare except blocks.

### Phase 6: Atomic Git Release and Pull Request Generation
Upon Critic approval, the Git Release agent initializes an ephemeral branch, creates a conventional commit, and compiles a comprehensive Pull Request markdown report containing root cause explanations, diff previews, and empirical before and after test receipts.

## 5. Ephemeral Sandbox and Stack Trace Sanitization Mechanics

The companion sandbox module provides execution isolation and intelligent error filtering:

- Subprocess Workspace Isolation: Each test execution runs within a dedicated temporary directory with isolated python paths and timeout enforcement.
- Noise Stripped Traceback Sanitization: Standard library, virtualenv, and test framework internal machinery are stripped from raw output, presenting the Coder agent with only high signal application frames and root exception lines.
- AST Security Inspection: Uses Python's native AST parser to detect security violations deterministically without requiring third party external dependencies.

## 6. Execution and Verification Guide

### File Manifest
- `sandbox.py`: Ephemeral workspace manager, noise stripped traceback parser, and AST security inspector.
- `agent.py`: LangGraph StateGraph implementation containing all agent nodes, conditional feedback routing, and runnable demonstration runner.
- `blueprint.json`: Structured metadata, role definitions, and workflow configuration.
- `README.md`: Complete architectural documentation and operational guide.

### Executing the Demonstration Run
To run the complete multi agent workflow and observe the TDD Red Green Audit cycle in action, run:

```bash
/home/idrees/job_agent/.venv/bin/python3 /home/idrees/Antigravity/agentic_workflows_vault/blueprints/workflow_2_autonomous_dev/agent.py
```
