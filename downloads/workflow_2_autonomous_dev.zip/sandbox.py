"""
Ephemeral Test Runner Sandbox & Empirical Verification Engine.

This module provides isolated execution harnesses, stack trace filtering,
and static AST security inspection for autonomous software engineering agents.
Conforms to the Devin / SWE-agent / OpenHands isolated runtime paradigm.
"""

from __future__ import annotations

import ast
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class ExecutionResult:
    """Structured receipt for command and test execution inside sandbox."""
    exit_code: int
    stdout: str
    stderr: str
    duration_seconds: float
    passed: bool
    stack_trace: str = ""
    failing_assertion: str = ""
    error_type: str = ""
    cleaned_output: str = ""
    executed_command: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "exit_code": self.exit_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "duration_seconds": round(self.duration_seconds, 3),
            "passed": self.passed,
            "stack_trace": self.stack_trace,
            "failing_assertion": self.failing_assertion,
            "error_type": self.error_type,
            "cleaned_output": self.cleaned_output,
            "executed_command": self.executed_command,
        }


class StackTraceCleaner:
    """Extracts and cleans Python stack traces, stripping library noise."""

    NOISE_PATTERNS = [
        r"site-packages[\\/]",
        r"dist-packages[\\/]",
        r"lib[\\/]python\d+\.\d+[\\/]",
        r"unittest[\\/]case\.py",
        r"_pytest[\\/]",
        r"pluggy[\\/]",
    ]

    @classmethod
    def extract_clean_trace(cls, raw_output: str) -> str:
        """Extracts minimal, high-signal traceback focused on application code."""
        if not raw_output:
            return ""

        tb_marker = "Traceback (most recent call last):"
        if tb_marker not in raw_output:
            summary_lines = []
            for line in raw_output.splitlines():
                if any(k in line for k in ["FAILED", "ERROR", "AssertionError", "Exception"]):
                    summary_lines.append(line.strip())
            return "\n".join(summary_lines[:10])

        parts = raw_output.split(tb_marker)
        relevant_part = tb_marker + parts[-1]

        lines = relevant_part.splitlines()
        cleaned_lines = [lines[0]]

        i = 1
        while i < len(lines):
            line = lines[i]
            if line.strip().startswith('File "'):
                is_noise = any(re.search(pat, line) for pat in cls.NOISE_PATTERNS)
                if not is_noise:
                    cleaned_lines.append(line)
                    if i + 1 < len(lines) and not lines[i + 1].strip().startswith('File "'):
                        cleaned_lines.append(lines[i + 1])
                        i += 1
                else:
                    if i + 1 < len(lines) and not lines[i + 1].strip().startswith('File "'):
                        i += 1
            else:
                if line.strip():
                    cleaned_lines.append(line)
            i += 1

        return "\n".join(cleaned_lines[-25:])

    @classmethod
    def extract_failing_assertion(cls, raw_output: str) -> str:
        """Extracts specific assertion message or fatal exception line."""
        if not raw_output:
            return ""

        for line in reversed(raw_output.splitlines()):
            stripped = line.strip()
            if any(stripped.startswith(prefix) for prefix in [
                "AssertionError", "ValueError", "TypeError", "KeyError",
                "IndexError", "ZeroDivisionError", "AttributeError", "RuntimeError"
            ]):
                return stripped
            if "FAILED" in stripped and "::" in stripped:
                return stripped

        return ""


class ASTSecurityAuditor:
    """Static AST inspector to enforce security, hygiene, and safety policies."""

    DANGEROUS_CALLS = {
        "eval", "exec", "__import__", "compile", "breakpoint"
    }

    SECRET_PATTERNS = [
        re.compile(r"sk-[a-zA-Z0-9_-]{20,}"),
        re.compile(r"ghp_[a-zA-Z0-9_-]{20,}"),
        re.compile(r"(?i)(api[_-]?key|secret|token|password)\s*[:=]\s*['\"][a-zA-Z0-9_\-]{16,}['\"]"),
    ]

    @classmethod
    def audit_source(cls, source_code: str, filename: str = "<code_snippet>") -> Tuple[bool, List[str]]:
        """Audits Python source code against security and safety standards."""
        issues: List[str] = []

        try:
            tree = ast.parse(source_code, filename=filename)
        except SyntaxError as err:
            return False, [f"SyntaxError on line {err.lineno}: {err.msg}"]

        for line_no, line in enumerate(source_code.splitlines(), start=1):
            for pattern in cls.SECRET_PATTERNS:
                if pattern.search(line):
                    issues.append(f"Security Alert line {line_no}: Potential hardcoded secret or token detected")

        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name):
                    if node.func.id in cls.DANGEROUS_CALLS:
                        issues.append(f"Security Alert line {node.lineno}: Use of forbidden function '{node.func.id}'")

                elif isinstance(node.func, ast.Attribute):
                    if node.func.attr == "system" and getattr(node.func.value, "id", "") == "os":
                        issues.append(f"Security Alert line {node.lineno}: Use of os.system is disallowed; use subprocess list args")
                    elif getattr(node.func.value, "id", "") == "subprocess":
                        for kw in node.keywords:
                            if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                                issues.append(f"Security Alert line {node.lineno}: subprocess with shell=True is disallowed")

            elif isinstance(node, ast.ExceptHandler):
                if node.type is None:
                    issues.append(f"Quality Warning line {node.lineno}: Bare 'except:' clause detected; specify exception types")

        passed = len(issues) == 0
        return passed, issues


class EphemeralSandbox:
    """Ephemeral isolated workspace for executing tests, linters, and patches."""

    def __init__(
        self,
        base_dir: Optional[str] = None,
        timeout_seconds: int = 30,
        keep_workspace: bool = False
    ) -> None:
        self.timeout_seconds = timeout_seconds
        self.keep_workspace = keep_workspace
        self._is_managed = base_dir is None

        if base_dir:
            self.workspace_dir = Path(base_dir).resolve()
            self.workspace_dir.mkdir(parents=True, exist_ok=True)
        else:
            self.workspace_dir = Path(tempfile.mkdtemp(prefix="agent_sandbox_")).resolve()

    def __enter__(self) -> EphemeralSandbox:
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self.cleanup()

    def cleanup(self) -> None:
        """Removes the ephemeral workspace if managed."""
        if self._is_managed and not self.keep_workspace and self.workspace_dir.exists():
            try:
                shutil.rmtree(self.workspace_dir)
            except OSError:
                pass

    def write_file(self, relative_path: str, content: str) -> str:
        """Writes content to relative path within sandbox workspace."""
        clean_rel = relative_path.lstrip("/\\")
        target_path = self.workspace_dir / clean_rel
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_text(content, encoding="utf-8")
        return str(target_path)

    def read_file(self, relative_path: str) -> str:
        """Reads content from relative path within sandbox workspace."""
        clean_rel = relative_path.lstrip("/\\")
        target_path = self.workspace_dir / clean_rel
        if not target_path.exists():
            raise FileNotFoundError(f"File not found in sandbox: {relative_path}")
        return target_path.read_text(encoding="utf-8")

    def file_exists(self, relative_path: str) -> bool:
        clean_rel = relative_path.lstrip("/\\")
        return (self.workspace_dir / clean_rel).exists()

    def run_command(
        self,
        cmd_args: List[str],
        env: Optional[Dict[str, str]] = None,
        timeout: Optional[int] = None
    ) -> ExecutionResult:
        """Executes a command safely inside the ephemeral workspace."""
        timeout_val = timeout or self.timeout_seconds
        start_time = time.time()
        exec_cmd_str = " ".join(cmd_args)

        run_env = os.environ.copy()
        run_env["PYTHONPATH"] = str(self.workspace_dir)
        run_env["PYTHONDONTWRITEBYTECODE"] = "1"
        if env:
            run_env.update(env)

        try:
            process = subprocess.run(
                cmd_args,
                cwd=str(self.workspace_dir),
                capture_output=True,
                text=True,
                timeout=timeout_val,
                env=run_env
            )
            duration = time.time() - start_time
            stdout = process.stdout
            stderr = process.stderr
            exit_code = process.returncode
            combined = f"{stdout}\n{stderr}".strip()

            clean_tb = StackTraceCleaner.extract_clean_trace(combined)
            failing_assert = StackTraceCleaner.extract_failing_assertion(combined)
            passed = (exit_code == 0)

            return ExecutionResult(
                exit_code=exit_code,
                stdout=stdout,
                stderr=stderr,
                duration_seconds=duration,
                passed=passed,
                stack_trace=clean_tb,
                failing_assertion=failing_assert,
                cleaned_output=combined,
                executed_command=exec_cmd_str
            )

        except subprocess.TimeoutExpired as err:
            duration = time.time() - start_time
            return ExecutionResult(
                exit_code=124,
                stdout=err.stdout or "" if isinstance(err.stdout, str) else "",
                stderr=f"TimeoutExpired: Process killed after {timeout_val} seconds",
                duration_seconds=duration,
                passed=False,
                stack_trace="",
                failing_assertion=f"Execution exceeded timeout limit ({timeout_val}s)",
                cleaned_output=f"TimeoutExpired: Process killed after {timeout_val} seconds",
                executed_command=exec_cmd_str
            )

        except Exception as exc:
            duration = time.time() - start_time
            return ExecutionResult(
                exit_code=1,
                stdout="",
                stderr=str(exc),
                duration_seconds=duration,
                passed=False,
                stack_trace=str(exc),
                failing_assertion=str(exc),
                cleaned_output=f"Sandbox Execution Error: {exc}",
                executed_command=exec_cmd_str
            )

    def execute_python_test(
        self,
        test_file_rel: str,
        timeout: Optional[int] = None
    ) -> ExecutionResult:
        """Executes a test file using python3 unittest or pytest runner."""
        python_exec = sys.executable
        cmd = [python_exec, "-m", "unittest", test_file_rel]
        return self.run_command(cmd, timeout=timeout)

    def audit_file_safety(self, relative_path: str) -> Tuple[bool, List[str]]:
        """Reads file from sandbox and runs AST security audit."""
        content = self.read_file(relative_path)
        return ASTSecurityAuditor.audit_source(content, filename=relative_path)

    def generate_receipt_markdown(self, result: ExecutionResult, step_label: str) -> str:
        """Produces a formatted markdown execution receipt for agent consumption."""
        status_badge = "PASSED" if result.passed else "FAILED"
        lines = [
            f"### Execution Receipt: {step_label}",
            f"- Status: `{status_badge}` (Exit Code: {result.exit_code})",
            f"- Command: `{result.executed_command}`",
            f"- Duration: `{result.duration_seconds:.3f}s`",
        ]

        if result.failing_assertion:
            lines.append(f"- Root Failure: `{result.failing_assertion}`")

        if result.stack_trace:
            lines.append("\n```text")
            lines.append("--- Isolated High-Signal Traceback ---")
            lines.append(result.stack_trace)
            lines.append("```")

        return "\n".join(lines)
