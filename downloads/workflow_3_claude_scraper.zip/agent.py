"""
Adaptive Browser Agent with Self Healing Interceptor
Architecture: Playwright Async Stealth Engine with Vision LLM Fallback Loop
Integrates: vision_healer.VisionHealerNode and vision_healer.SelectorCache
"""

import argparse
import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse
from pydantic import BaseModel, Field
from playwright.async_api import (
    async_playwright,
    Browser,
    BrowserContext,
    Page,
    Playwright,
    TimeoutError as PlaywrightTimeoutError,
    Error as PlaywrightError
)

# Relative import support
current_dir = Path(__file__).resolve().parent
if str(current_dir) not in sys.path:
    sys.path.insert(0, str(current_dir))

from vision_healer import (
    SelectorCache,
    VisionHealerNode,
    VisionElementResolution
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger("AdaptiveAgent")


# -----------------------------------------------------------------------------
# 1. Pydantic Schemas for Target Extraction Specs and Outputs
# -----------------------------------------------------------------------------

class FieldExtractionSpec(BaseModel):
    """Specification defining an individual target field on a web page."""
    field_key: str = Field(..., description="Unique programmatic key for this field")
    description: str = Field(..., description="Human visual intent describing the element")
    default_selector: str = Field(..., description="Initial baseline CSS or XPath selector")
    action_type: str = Field(default="extract_text", description="Action: extract_text, extract_attribute, click")
    target_attribute: Optional[str] = Field(default=None, description="Attribute name when action is extract_attribute")
    is_required: bool = Field(default=True, description="Whether failure to extract should raise an exception")


class FieldExtractionResult(BaseModel):
    """Extracted data point and execution telemetry."""
    field_key: str
    value: Optional[str] = None
    selector_used: str
    resolved_via: str = Field(..., description="fast_path_cache, fast_path_default, vision_healed, or coordinate_grounded")
    latency_ms: float
    success: bool


class ScrapedJobRecord(BaseModel):
    """Normalized structured output model for job postings."""
    title: str = Field(..., description="Job role title")
    company: str = Field(..., description="Company name")
    location: str = Field(..., description="Location or remote indicator")
    apply_url: Optional[str] = Field(default=None, description="Direct URL or action link")
    salary_range: Optional[str] = Field(default="Not disclosed", description="Compensation range")
    extracted_at: float = Field(default_factory=time.time)


# -----------------------------------------------------------------------------
# 2. Stealth Browser Configuration and Injection
# -----------------------------------------------------------------------------

class StealthController:
    """Configures Playwright contexts with evasion techniques against anti bot detection."""

    DEFAULT_USER_AGENT: str = (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    )

    @classmethod
    async def configure_stealth_context(
        cls,
        browser: Browser,
        viewport_width: int = 1440,
        viewport_height: int = 900,
        user_agent: Optional[str] = None
    ) -> BrowserContext:
        """Instantiates an isolated context equipped with fingerprint masking scripts."""
        context = await browser.new_context(
            viewport={"width": viewport_width, "height": viewport_height},
            user_agent=user_agent or cls.DEFAULT_USER_AGENT,
            locale="en-US",
            timezone_id="America/New_York",
            has_touch=False,
            is_mobile=False,
            device_scale_factor=1
        )

        # Inject stealth scripts before any page scripts execute
        stealth_js = """
        // 1. Remove automation markers
        Object.defineProperty(navigator, 'webdriver', {
            get: () => undefined
        });

        // 2. Mock Chrome runtime
        window.chrome = {
            runtime: {},
            loadTimes: function() {},
            csi: function() {},
            app: {}
        };

        // 3. Mock plugins and languages
        Object.defineProperty(navigator, 'languages', {
            get: () => ['en-US', 'en']
        });
        Object.defineProperty(navigator, 'plugins', {
            get: () => [1, 2, 3, 4, 5]
        });

        // 4. Spoof WebGL vendor and renderer
        const getParameter = WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter = function(parameter) {
            if (parameter === 37445) {
                return 'Google Inc. (NVIDIA)';
            }
            if (parameter === 37446) {
                return 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3080 Direct3D11 vs_5_0 ps_5_0, D3D11)';
            }
            return getParameter.apply(this, arguments);
        };
        """
        await context.add_init_script(stealth_js)
        return context


# -----------------------------------------------------------------------------
# 3. Adaptive Scraper Agent with Error Interceptor and Vision Fallback
# -----------------------------------------------------------------------------

class AdaptiveScraperAgent:
    """
    High speed web automation controller.
    Runs deterministic Playwright selectors on fast path.
    Intercepts DOM failures and triggers Gemini Flash Vision self healing loops.
    """

    def __init__(
        self,
        cache_file: str = "selector_cache.json",
        gemini_api_key: Optional[str] = None,
        model_name: str = "gemini-flash-lite-latest",
        fast_path_timeout_ms: int = 2500
    ):
        self.cache = SelectorCache(cache_file=cache_file)
        self.vision = VisionHealerNode(api_key=gemini_api_key, model_name=model_name)
        self.fast_path_timeout_ms = fast_path_timeout_ms
        self.stats = {
            "fast_path_hits": 0,
            "vision_healed_count": 0,
            "coordinate_grounded_count": 0,
            "failures": 0
        }

    def _extract_domain(self, url: str) -> str:
        """Extracts normalized netloc domain from a URL."""
        parsed = urlparse(url)
        return parsed.netloc or "default_domain"

    async def extract_field_with_healing(
        self,
        page: Page,
        domain: str,
        spec: FieldExtractionSpec
    ) -> FieldExtractionResult:
        """
        Attempts fast path extraction using cached or default selector.
        Upon failure, intercepts the error, captures screenshot, and heals locator.
        """
        t0 = time.time()
        cached_selector = self.cache.get_selector(domain, spec.field_key)
        active_selector = cached_selector or spec.default_selector
        is_from_cache = cached_selector is not None

        logger.info(
            f"Testing locator for [{spec.field_key}] on [{domain}]: {active_selector} "
            f"(Source: {'Cache' if is_from_cache else 'Default'})"
        )

        # ---------------------------------------------------------------------
        # 1. Deterministic Fast Path Execution
        # ---------------------------------------------------------------------
        try:
            element = page.locator(active_selector).first
            await element.wait_for(state="visible", timeout=self.fast_path_timeout_ms)

            if spec.action_type == "extract_text":
                val = (await element.inner_text()).strip()
                if val:
                    elapsed = (time.time() - t0) * 1000.0
                    self.cache.record_success(domain, spec.field_key)
                    self.stats["fast_path_hits"] += 1
                    logger.info(f"Fast path success for [{spec.field_key}] in {elapsed:.1f}ms: '{val}'")
                    return FieldExtractionResult(
                        field_key=spec.field_key,
                        value=val,
                        selector_used=active_selector,
                        resolved_via="fast_path_cache" if is_from_cache else "fast_path_default",
                        latency_ms=elapsed,
                        success=True
                    )
            elif spec.action_type == "extract_attribute" and spec.target_attribute:
                val = await element.get_attribute(spec.target_attribute)
                if val:
                    elapsed = (time.time() - t0) * 1000.0
                    self.cache.record_success(domain, spec.field_key)
                    self.stats["fast_path_hits"] += 1
                    return FieldExtractionResult(
                        field_key=spec.field_key,
                        value=val.strip(),
                        selector_used=active_selector,
                        resolved_via="fast_path_cache" if is_from_cache else "fast_path_default",
                        latency_ms=elapsed,
                        success=True
                    )
            elif spec.action_type == "click":
                await element.click()
                elapsed = (time.time() - t0) * 1000.0
                self.cache.record_success(domain, spec.field_key)
                self.stats["fast_path_hits"] += 1
                return FieldExtractionResult(
                    field_key=spec.field_key,
                    value="clicked",
                    selector_used=active_selector,
                    resolved_via="fast_path_cache" if is_from_cache else "fast_path_default",
                    latency_ms=elapsed,
                    success=True
                )

        except (PlaywrightTimeoutError, PlaywrightError, Exception) as fast_path_error:
            logger.warning(
                f"Fast path failed for [{spec.field_key}] with selector '{active_selector}': {fast_path_error}"
            )
            self.cache.record_failure(domain, spec.field_key)

        # ---------------------------------------------------------------------
        # 2. Error Interceptor & Multimodal Vision Recovery Trigger
        # ---------------------------------------------------------------------
        logger.info(f"Triggering Gemini Vision Self Healing loop for target [{spec.field_key}]...")
        screenshot_bytes = await page.screenshot(type="png", full_page=False)
        viewport = page.viewport_size or {"width": 1440, "height": 900}

        resolution: VisionElementResolution = await self.vision.heal_locator(
            screenshot_bytes=screenshot_bytes,
            target_description=spec.description,
            failed_selector=active_selector,
            page_url=page.url,
            viewport_size=viewport
        )

        if not resolution.found:
            logger.error(f"Vision Node could not visually locate [{spec.field_key}]")
            self.stats["failures"] += 1
            if spec.is_required:
                raise RuntimeError(f"Failed to locate required field [{spec.field_key}] on {domain}")
            return FieldExtractionResult(
                field_key=spec.field_key,
                value=None,
                selector_used=active_selector,
                resolved_via="failed",
                latency_ms=(time.time() - t0) * 1000.0,
                success=False
            )

        new_selector = resolution.recommended_selector
        logger.info(f"Proposed healed selector: {new_selector} (Identified text: '{resolution.visual_text}')")

        # ---------------------------------------------------------------------
        # 3. Live Verification of Healed Selector
        # ---------------------------------------------------------------------
        try:
            healed_element = page.locator(new_selector).first
            await healed_element.wait_for(state="visible", timeout=3000)

            if spec.action_type == "extract_text":
                verified_val = (await healed_element.inner_text()).strip()
            elif spec.action_type == "extract_attribute" and spec.target_attribute:
                verified_val = (await healed_element.get_attribute(spec.target_attribute) or "").strip()
            elif spec.action_type == "click":
                await healed_element.click()
                verified_val = "clicked"
            else:
                verified_val = resolution.visual_text or ""

            # Update persistent cache with verified selector
            self.cache.set_selector(
                domain=domain,
                field_key=spec.field_key,
                selector=new_selector,
                selector_type=resolution.aria_role or "aria_role",
                visual_text=resolution.visual_text,
                bounding_box_2d=resolution.bounding_box_2d
            )
            elapsed = (time.time() - t0) * 1000.0
            self.stats["vision_healed_count"] += 1
            logger.info(f"Successfully healed and verified locator for [{spec.field_key}] in {elapsed:.1f}ms")

            return FieldExtractionResult(
                field_key=spec.field_key,
                value=verified_val,
                selector_used=new_selector,
                resolved_via="vision_healed",
                latency_ms=elapsed,
                success=True
            )

        except Exception as verify_err:
            logger.warning(f"Healed selector verification failed: {verify_err}. Engaging spatial fallback.")

        # ---------------------------------------------------------------------
        # 4. Spatial Coordinate Fallback Execution
        # ---------------------------------------------------------------------
        if resolution.bounding_box_2d:
            px_x, px_y = VisionHealerNode.calculate_pixel_coordinates(
                resolution.bounding_box_2d,
                viewport["width"],
                viewport["height"]
            )
            logger.info(f"Executing spatial coordinate action at ({px_x:.1f}, {px_y:.1f})")

            if spec.action_type == "click":
                await page.mouse.click(px_x, px_y)
                value_result = "clicked_coordinate"
            else:
                value_result = resolution.visual_text or "Coordinate Grounded Value"

            elapsed = (time.time() - t0) * 1000.0
            self.stats["coordinate_grounded_count"] += 1

            return FieldExtractionResult(
                field_key=spec.field_key,
                value=value_result,
                selector_used=f"coord:({int(px_x)},{int(px_y)})",
                resolved_via="coordinate_grounded",
                latency_ms=elapsed,
                success=True
            )

        self.stats["failures"] += 1
        elapsed = (time.time() - t0) * 1000.0
        return FieldExtractionResult(
            field_key=spec.field_key,
            value=resolution.visual_text,
            selector_used="unverified_visual_text",
            resolved_via="visual_fallback",
            latency_ms=elapsed,
            success=True
        )

    async def scrape_fields(
        self,
        page: Page,
        specs: List[FieldExtractionSpec]
    ) -> Dict[str, FieldExtractionResult]:
        """Iterates over all field specifications and extracts values with self healing."""
        domain = self._extract_domain(page.url)
        results: Dict[str, FieldExtractionResult] = {}

        for spec in specs:
            result = await self.extract_field_with_healing(page, domain, spec)
            results[spec.field_key] = result

        return results

    async def run_scrape_pipeline(
        self,
        url: str,
        specs: List[FieldExtractionSpec],
        headless: bool = True
    ) -> Dict[str, Any]:
        """Top level orchestrator managing browser lifecycle and structured extraction."""
        async with async_playwright() as playwright:
            browser = await playwright.chromium.launch(headless=headless)
            context = await StealthController.configure_stealth_context(browser)
            page = await context.new_page()

            logger.info(f"Navigating to target URL: {url}")
            await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            await page.wait_for_timeout(1500)

            extracted_results = await self.scrape_fields(page, specs)
            await browser.close()

            summary = {
                "url": url,
                "domain": self._extract_domain(url),
                "timestamp": time.time(),
                "fields": {k: v.model_dump() for k, v in extracted_results.items()},
                "engine_telemetry": self.stats
            }
            return summary


# -----------------------------------------------------------------------------
# 4. Integrated Self Healing Demonstration
# -----------------------------------------------------------------------------

async def run_demonstration(headless: bool = True):
    """
    Demonstrates the end to end self healing cycle:
    1. Loads an HTML page with modified obfuscated markup.
    2. Runs an initial pass with a broken legacy selector to trigger Vision Healing.
    3. Verifies that the new selector is cached in selector_cache.json.
    4. Runs a second pass to prove sub second fast path cache retrieval.
    """
    logger.info("=================================================================")
    logger.info("Launching Self Healing Scraper Blueprint Verification Demo")
    logger.info("=================================================================")

    # Sample dynamic HTML page simulating modern framework obfuscated classes
    demo_html = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>TechCareers AI Portal</title>
        <style>
            body { font-family: sans-serif; padding: 40px; background: #0f172a; color: #f8fafc; }
            .card { background: #1e293b; padding: 30px; border-radius: 12px; max-width: 600px; margin: 0 auto; }
            .rand-x92f { font-size: 28px; font-weight: bold; color: #38bdf8; margin-bottom: 12px; }
            .org-hash-77b { font-size: 18px; color: #94a3b8; margin-bottom: 8px; }
            .loc-badge-q12 { display: inline-block; background: #334155; padding: 6px 14px; border-radius: 20px; font-size: 14px; }
            .btn-action-k83 { display: inline-block; margin-top: 24px; background: #0284c7; color: #fff; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: bold; border: none; cursor: pointer; }
        </style>
    </head>
    <body>
        <div class="card">
            <!-- Notice classes are obfuscated hashes that change across deployments -->
            <h1 class="rand-x92f" role="heading" aria-level="1">Senior AI Automation Architect</h1>
            <div class="org-hash-77b" data-testid="hiring-org">Linkrypt Enterprise Solutions</div>
            <div class="loc-badge-q12">Remote Global Contractor</div>
            <br>
            <button class="btn-action-k83" role="button" name="Apply on Company Site">Apply on Company Site</button>
        </div>
    </body>
    </html>
    """

    cache_file = "demo_selector_cache.json"
    if os.path.exists(cache_file):
        os.remove(cache_file)

    agent = AdaptiveScraperAgent(cache_file=cache_file, fast_path_timeout_ms=1500)

    # Broken legacy selectors designed to fail and trigger vision healing
    specs = [
        FieldExtractionSpec(
            field_key="job_title",
            description="The primary job title heading of the position",
            default_selector=".old-broken-job-title, #legacy-header-title",
            action_type="extract_text"
        ),
        FieldExtractionSpec(
            field_key="company_name",
            description="The hiring company or organization name",
            default_selector=".old-company-tag, div.legacy-employer",
            action_type="extract_text"
        ),
        FieldExtractionSpec(
            field_key="location",
            description="The workplace location or remote contractor status",
            default_selector=".old-location-selector",
            action_type="extract_text"
        )
    ]

    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=headless)
        context = await StealthController.configure_stealth_context(browser)
        page = await context.new_page()

        # Load dynamic HTML
        await page.set_content(demo_html)
        if not headless:
            await asyncio.sleep(2.0)

        # PASS 1: Broken selectors will trigger Vision Healing
        logger.info("\n--- PASS 1: Executing with Broken Legacy Selectors (Triggering Vision Healer) ---")
        results_pass1 = await agent.scrape_fields(page, specs)

        logger.info("\nPass 1 Results:")
        for k, v in results_pass1.items():
            logger.info(f"Field [{k}]: '{v.value}' | Via: {v.resolved_via} | Latency: {v.latency_ms:.1f}ms")

        if not headless:
            await asyncio.sleep(2.0)

        # PASS 2: Re-run to verify sub second fast path cache retrieval
        logger.info("\n--- PASS 2: Executing Second Run (Deterministic Fast Path Cache Verification) ---")
        t_start = time.time()
        results_pass2 = await agent.scrape_fields(page, specs)
        total_p2_time = (time.time() - t_start) * 1000.0

        logger.info(f"\nPass 2 Completed in {total_p2_time:.1f}ms Total:")
        for k, v in results_pass2.items():
            logger.info(f"Field [{k}]: '{v.value}' | Via: {v.resolved_via} | Latency: {v.latency_ms:.1f}ms")

        if not headless:
            await asyncio.sleep(3.0)

        await browser.close()

    # Clean up demo cache
    if os.path.exists(cache_file):
        os.remove(cache_file)

    logger.info("\n=================================================================")
    logger.info("Verification Demo Completed Successfully")
    logger.info(f"Telemetry: {json.dumps(agent.stats, indent=2)}")
    logger.info("=================================================================")


# -----------------------------------------------------------------------------
# 5. Command Line Interface Runner
# -----------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Production Ready Adaptive Playwright Scraper with Vision Fallback"
    )
    parser.add_argument(
        "--demo",
        action="store_true",
        help="Run the integrated self healing verification demo"
    )
    parser.add_argument(
        "--url",
        type=str,
        help="Target URL to scrape"
    )
    parser.add_argument(
        "--cache-file",
        type=str,
        default="selector_cache.json",
        help="Path to persistent selector cache JSON file"
    )
    parser.add_argument(
        "--headed",
        action="store_true",
        help="Run browser with visible window for screencast recording"
    )

    args = parser.parse_args()
    is_headless = not args.headed

    if args.demo or not args.url:
        asyncio.run(run_demonstration(headless=is_headless))
    else:
        # Default job scraping specs for CLI execution
        default_specs = [
            FieldExtractionSpec(
                field_key="job_title",
                description="The primary job title heading of the position",
                default_selector="h1, .job-title, [data-testid='job-title']"
            ),
            FieldExtractionSpec(
                field_key="company_name",
                description="The hiring company or organization name",
                default_selector=".company-name, [data-testid='company-name'], .employer"
            ),
            FieldExtractionSpec(
                field_key="location",
                description="The workplace location or remote status",
                default_selector=".location, [data-testid='job-location'], .workplace-type"
            )
        ]
        agent = AdaptiveScraperAgent(cache_file=args.cache_file)
        result = asyncio.run(agent.run_scrape_pipeline(args.url, default_specs, headless=args.headless))
        print("\nScrape Pipeline Output:")
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
