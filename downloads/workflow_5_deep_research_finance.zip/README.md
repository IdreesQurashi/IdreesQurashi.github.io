# Autonomous Deep Research and Financial Intelligence Blueprint

## 1. System Overview and Provenance

- **Blueprint Title:** Autonomous Deep Research and Financial Intelligence Engine
- **Primary Authorities and System Provenance:**
  - Lance Martin: Machine Learning Engineer, LangChain
  - Harrison Chase: Chief Executive Officer and Co Founder, LangChain
  - Ed Donner: Former Managing Director at JPMorgan Chase, Autonomous Trading Systems and AI Engineering Instructor
- **Canonical Codebases and Foundations:**
  - LangChain Open Deep Research Repository (`langchain ai/open deep research`)
  - LangGraph Stateful Multi Agent Engine (`langchain ai/langgraph`)
  - Latent Space: Context Engineering for Deep Agents
  - Ed Donner AI Engineering: Financial Agent and Trading Floor Blueprints
- **Domain Specialization:** Institutional grade autonomous financial equity research, SEC 10K and 10Q quantitative analysis, earnings call transcript cross examination, and deterministic Python arithmetic execution with zero hallucination verification.

***

## 2. Institutional Failure Modes Solved

Traditional conversational LLMs and naive Retrieval Augmented Generation systems consistently fail in institutional equity analysis due to five structural bottlenecks:

1. **Massive Multi Page SEC Filings (10K and 10Q):**
   - Annual SEC 10K filings frequently span 150 to 300 pages of dense legal disclosures, risk factors (Item 1A), management discussion and analysis (Item 7 MD&A), and notes to consolidated financial statements (Item 8). Naive character count or token chunking splits financial tables mid row, detaching figures from column headers and footnote anchors.
2. **Unstructured Multi Speaker Earnings Call Transcripts:**
   - Quarterly earnings calls contain nuanced guidance shifts, executive tone variance, and pointed analyst questioning. Standard vector search retrieves isolated fragments without capturing narrative progression or temporal context.
3. **LLM Arithmetic Hallucination in Financial Calculations:**
   - Generative LLMs are probabilistic token prediction models. They cannot perform reliable floating point arithmetic. When calculating year over year growth rates, EBITDA margins, free cash flow conversion, net debt to adjusted EBITDA leverage, or compound annual growth rates, language models frequently hallucinate intermediate figures, drop decimal places, or invert algebraic signs.
4. **Citation Fabrication and Inverted Provenance:**
   - Conventional chatbots fabricate citations or assign figures to incorrect fiscal quarters. Institutional analysts require 100 percent verifiable lineage with exact filing accession numbers, filing types, sections, and page references.
5. **Infinite Reflection and Graph Stagnation:**
   - Unbounded critique loops can cause agentic workflows to cycle indefinitely when confronting complex filings, burning API budgets without reaching convergence.

This blueprint eliminates every single one of these failure modes through an orchestrated combination of LangGraph state machine mechanics, Docling table aware chunking, hybrid vector and BM25 search, a deterministic Python math sandbox, and an adversarial compliance critic.

***

## 3. High Level Workflow Architecture

```
                       User Investment Thesis / Research Objective
                                            |
                                            v
                         [Query Decomposition & Planning Node]
                                            |
                         (LangGraph Dynamic Send API Fan Out)
                        /                   |                   \
                       v                    v                    v
              [SEC 10K/10Q Worker]  [Transcript Worker]   [Web / Market Worker]
              (Docling Table Chunks) (Executive Q&A Store) (Macro Feeds / News)
                       \                    |                    /
                        \                   |                   /
                         v                  v                  v
                       (Global State Aggregation: operator.add)
                                            |
                                            v
                     [Deterministic Quantitative Python Sandbox]
                     * AST Restricted Code Execution Environment
                     * Decimal Precision Math (Zero Hallucination)
                     * SHA 256 Cryptographic Audit Fingerprints
                                            |
                                            v
                           [Lead Dossier Synthesis Node]
                           * Inline Citation Placement
                           * Audited Financial Metrics Table
                                            |
                                            v
                         [Adversarial Compliance Critic Node]
                         * Verification 1: Floating Point Math Audit
                         * Verification 2: 100% Citation Grounding Check
                                            |
                         +------------------+------------------+
                         |                                     |
               (Verification Failed)                  (Audit Verified)
                         |                                     |
                         v                                     v
                 [Replan / Refine]                 [Final Institutional Dossier]
```

***

## 4. Deep Architectural Components

### A. Query Decomposition and Planning Node
- Evaluates the overarching investment objective submitted by the analyst.
- Deconstructs the research thesis into specialized, typed Pydantic micro tasks:
  - Quantitative Tasks: Extract consolidated income statements, balance sheets, and cash flows across multiple fiscal intervals.
  - Narrative Tasks: Extract Item 7 MD&A disclosures regarding segment gross margin compression, capital allocation priorities, and depreciation schedules.
  - Guidance Tasks: Parse executive remarks and forward looking statements from quarterly earnings call transcripts.
  - Risk Tasks: Extract Item 1A disclosures concerning hardware supply bottlenecks, power interconnect delays, and regulatory investigations.
- Initializes the `FinancialResearchState` container with structured task parameters and recursion guards.

### B. Docling Table Aware Ingestion and Chunking
- Financial filings depend fundamentally on tabular data integrity.
- Rather than slicing text by arbitrary character boundaries, the Docling ingestion engine treats Markdown and HTML tables as atomic semantic units.
- Row alignments, multi tier headers, negative parenthesis notations, and footnote anchors (`[Note 3]`, `[Note 8]`) remain structurally intact.
- Extracted tables are converted into structured numeric arrays available directly to downstream quantitative nodes.

### C. Multi Source Hybrid Retrieval: Dense Embeddings and Sparse BM25
- Dense Vector Search: Employs semantic embeddings (pgvector, ChromaDB) to capture qualitative intent, thematic risk disclosures, and conversational executive tone.
- Sparse Keyword Search: Employs BM25 token indexing with tuned term frequency saturation (k1=1.5) and document length normalization (b=0.75) to guarantee exact retrieval for specialized accounting line items such as additions to property and equipment, operating lease obligations, or basis points margin delta.
- Reciprocal Rank Fusion: Merges dense and sparse retrieval ranks deterministically to surface the single most authoritative context chunks without bias.

### D. Deterministic Quantitative Python Sandbox (Math Sandbox)
- Enforces an absolute firewall between generative language models and mathematical computations.
- Key execution features:
  - Abstract Syntax Tree Security Inspector: Scans dynamically generated algorithmic code before compilation. Completely blocks unauthorized modules, file system operations, process invocations, and Python dunder introspection (`__subclasses__`, `__globals__`).
  - Exact Decimal Arithmetic: Employs standard Python `Decimal` objects configured with institutional `ROUND_HALF_UP` rounding. Prevents IEEE 754 binary floating point inaccuracies.
  - Automated Core Metrics: Calculates Free Cash Flow (FCF = Operating Cash Flow minus CAPEX), FCF Margins, sequential YoY Growth Rates, Compound Annual Growth Rates (CAGR), Net Debt, and Net Debt to EBITDA Leverage Multiples.
  - Cryptographic Traceability: Computes SHA 256 hash digests of raw numerical inputs and computed outputs. Logs comprehensive human readable lineage steps for regulatory audit defense.
  - Resilient Standalone Fallback: Executes seamlessly with high speed Pandas and NumPy libraries when installed, while maintaining full standalone pure Python execution when dependencies are absent.

### E. Lead Dossier Synthesis Node
- Synthesizes verified quantitative outputs with contextual qualitative findings.
- Embeds standardized citation anchors for every factual claim (for example: `[Citation: SEC_10K_FY24_ITEM7]`).
- Formats a comprehensive institutional Markdown dossier containing:
  - Executive Investment Summary
  - Audited Quantitative Performance Matrix
  - MD&A Segment Margin Compression Deep Dive
  - Earnings Guidance and Capital Allocation Breakdown
  - Risk Disclosures and Operational Constraints
  - Verbatim Source Lineage and Provenance Index

### F. Adversarial Compliance Critic Node
- Functions as an independent algorithmic risk officer prior to dossier delivery.
- Verification Checks:
  - Numerical Cross Examination: Verifies every single numerical metric in the synthesized report against the execution output of the math sandbox. If any figure diverges by more than 0.0001 percent, the report is rejected.
  - Grounding and Citation Verification: Ensures that all forward guidance claims and operational statements possess valid citation tags grounded in retrieved filing chunks.
  - Infinite Recursion Protection: Implements a hard iteration ceiling (default 3 cycles). If unresolved ambiguities persist after 3 cycles, the report delivers with explicit audit flags rather than hanging the system.

***

## 5. LangGraph Dynamic Send API Fan Out Mechanics

In traditional fixed graphs, retrieval must proceed sequentially or through rigid static branches. This blueprint leverages the LangGraph `Send` primitive to implement dynamic, runtime fan out:

1. The Planning node inspects the user query and generates `N` discrete `FinancialSubTask` objects.
2. The dynamic conditional router `dispatch_subtasks` maps each sub task into an independent `Send("retrieval_worker_node", sub_task)` instruction.
3. LangGraph spawns parallel execution instances of `retrieval_worker_node`. Each worker queries its assigned document corpus (SEC filings, call transcripts, or market data).
4. The global graph state utilizes `Annotated[List[RetrievedFact], operator.add]` as a reducer channel. All worker returns are seamlessly concatenated without race conditions or overwriting global keys.
5. Once all dispatched sub tasks complete their retrieval, LangGraph automatically fans in and transitions execution to the `deterministic_math` node.

***

## 6. Complete Blueprint File Manifest

The blueprint directory contains three core executable modules and a structured configuration manifest:

- `pipeline.py`: Complete LangGraph state machine orchestrating dynamic fan out, Docling chunking, hybrid BM25 retrieval, dossier drafting, and adversarial critique. Contains an integrated graph engine fallback ensuring full execution across standard Python environments.
- `math_sandbox.py`: Isolated quantitative calculation sandbox. Features AST security validation, Decimal precision financial algorithms, SHA 256 hashing, and Markdown table generation.
- `blueprint.json`: Standardized JSON export defining graph nodes, conditional edges, security policies, chunking parameters, and runtime requirements.
- `README.md`: Comprehensive architectural documentation and institutional usage manual.

***

## 7. Execution and Verification Guide

To run the deterministic math sandbox standalone verification:
```bash
python3 math_sandbox.py
```

To run the complete end to end financial research pipeline:
```bash
python3 pipeline.py
```

Expected Execution Output:
- Verification of dynamic fan out across research subtasks.
- Deterministic calculation of Microsoft FY22, FY23, FY24 Free Cash Flow, Margins, and CAGR.
- Generation of SHA 256 input and output verification hashes.
- Successful adversarial critique pass confirming zero arithmetic hallucination.
- Fully rendered institutional equity research dossier with complete citation provenance.

***

## 8. Defensive Engineering Safeguards

- **Context Window Protection:** High volume SEC filings are filtered prior to prompt inclusion. Only verified Docling Markdown tables and target thematic paragraphs enter the synthesis context.
- **AST Security Guardrails:** Custom user submitted calculations are scanned against a strict AST whitelist, completely preventing remote code execution or file system compromise.
- **Zero Hallucination Guarantee:** Generative LLMs never compute mathematical values. All calculations are executed deterministically in Python with reproducible audit lineage.
- **Strict Iteration Caps:** Bounded recursion prevents infinite graph cycles, ensuring predictable latency and controlled API expenditures.
